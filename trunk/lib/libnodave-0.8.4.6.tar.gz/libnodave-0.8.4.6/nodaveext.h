//#include "nodave.h" 
char * DECL2 daveStrerrorExt(int code);
