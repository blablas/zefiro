wine c:/pp/bin/win32/fpc -B -Sd testPPI.pas
wine c:/pp/bin/win32/fpc -B -Sd testMPI.pas
wine c:/pp/bin/win32/fpc -B -Sd testISO_TCP.pas
wine c:/pp/bin/win32/fpc -B -Sd testIBH.pas
wine c:/pp/bin/win32/fpc -B -Sd testPPI_IBH.pas
